function mostrar(){

   document.getElementById("text2").style.display = "block";

}
function ocultar(){
   
    document.getElementById("text2").style.display = "none";
}
function agrandar(){
    document.getElementById("img").style.width = "100%";
}
function achicar(){
    document.getElementById("img").style.width = "20%";
}
function letra(){
    document.getElementById("caja3").style.fontSize = "xx-large"
}
