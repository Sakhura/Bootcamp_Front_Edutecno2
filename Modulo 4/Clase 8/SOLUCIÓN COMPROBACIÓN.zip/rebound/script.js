let validador = {
    set: function (objeto, propiedad, valor) {
        var error;

        // Solo validará la propiedad 'edad':
        if (propiedad === 'edad') {
            // Aquí validamos de que solo sea un número:
            if (typeof valor !== 'number' || Number.isNaN(valor)) {
                error = 'Edad debe ser un numero'
                alert(error)


                // if positive
            } else if (valor > 0) {
                // is it greater than 18?
                if (valor >= 18) {
                    // Si cumple con el criterio, se asigna el valor:
                    objeto[propiedad] = valor;
                    return true;
                } else {
                    error = 'Debes ser mayor de edad para crear una reservación'
                    alert(error)

                }
            } else {
                error = 'Edad debe ser un numero positivo'
                alert(error)

            }

        }
    }
}
// Nuestro Proxy
let reservacion = {
    nombre: "",
    apellido: "",
    email: "",
    fecha: "",
    edad: 0
}

let validaReservacion = new Proxy(reservacion, validador);


//Tratamos de asignar valores a la propiedad “edad”
// validaReservacion.edad = 'joven'; //Error: solo debe ser numeros
// validaReservacion.edad = -36; //Error: solo numeros positvos
// validaReservacion.edad = 62; //¡Perfecto!
console.log(validaReservacion.edad)

$('button').click(function () {


    reservacion['nombre'] = $('#firstName').val()
    reservacion['apellido'] = $('#lastName').val()
    reservacion['email'] = $('#email').val()
    // reservacion['edad']=Number($('#age').val())
    // validaReservacion.edad = Number($('#age').val())
    if (!(validaReservacion.edad = Number($('#age').val()))) {
        console.log(validaReservacion.edad = Number($('#age').val()))
        console.log(validaReservacion.edad)
        console.log(validaReservacion.validador)
    }
    reservacion['fecha'] = $('#date').val()
    console.log(reservacion)
})

