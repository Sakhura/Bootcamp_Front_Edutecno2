// Objeto para guardar todo.
const vehiculo = {
    marca: "Peakauto",
    modelo: "Goenx",
    motor: {
        tipo: "4 CILINDROS EN LÍNEA",
        // presion: "",
        bloque: "Aleación/",
        desplazamiento: "1.99/1996",
        caballosDeFuerza: "155 @ 6500",
        lineaRoja: 6700,
        // sistemaSmartAssist: "",
        inyeccionDeCombustible: "PUNTOS MÚLTIPLES"
        // ,encendidoRemotoDelMotor: ""
    }

}

// Declaracion de variables.
let marca, modelo, tipo, presion, bloque, desplazamiento, caballosDeFuerza, lineaRoja, sistemaSmartAssist, inyeccionDeCombustible, encendidoRemotoDelMotor;

// Uso del operador de asignacion nula y el operador opcional de encadenamiento.
marca ??= vehiculo.marca;
modelo ??= vehiculo.modelo;
tipo ??= vehiculo.motor.tipo;
presion ??= vehiculo.motor?.presion;
bloque ??= vehiculo.motor.bloque;
desplazamiento ??= vehiculo.motor.desplazamiento;
caballosDeFuerza ??= vehiculo.motor.caballosDeFuerza;
lineaRoja ??= vehiculo.motor.lineaRoja;
sistemaSmartAssist ??= vehiculo.motor?.sistemaSmartAssist;
inyeccionDeCombustible ??= vehiculo.motor.inyeccionDeCombustible;
encendidoRemotoDelMotor ??= vehiculo.motor?.encendidoRemotoDelMotor;

// Mostrar todo por consola.
console.log(marca)
console.log(modelo)
console.log(tipo)
console.log(presion)
console.log(bloque)
console.log(desplazamiento)
console.log(caballosDeFuerza)
console.log(lineaRoja)
console.log(sistemaSmartAssist)
console.log(inyeccionDeCombustible)
console.log(encendidoRemotoDelMotor)












